"""School administrator tool. Run on the machine that holds the database.
  python manage.py add-class C-6B "Grade 6 Blue"
  python manage.py add-teacher "Ms Wanjiru" --class C-6B            (asks for a password)
  python manage.py add-learner L-6B-01 --class C-6B --name "Amani K." --age-band 9-12
  python manage.py import-learners C-6B learners.csv                (columns: id,name,age_band)
  python manage.py consent L-6B-01 granted --by "Ms Wanjiru"
  python manage.py export L-6B-01 > learner.json | erase L-6B-01 --by "Head Teacher" | backup out.db | audit"""
import argparse, getpass, csv, json, sqlite3, sys, time
import core

ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd", required=True)
s = sub.add_parser("add-class"); s.add_argument("id"); s.add_argument("name"); s.add_argument("--grade", default="")
s = sub.add_parser("add-teacher"); s.add_argument("name"); s.add_argument("--role", default="teacher"); s.add_argument("--class", dest="classes", action="append", default=[]); s.add_argument("--password")
s = sub.add_parser("add-learner"); s.add_argument("id"); s.add_argument("--class", dest="cls", required=True); s.add_argument("--name", default=""); s.add_argument("--age-band", default="9-12")
s = sub.add_parser("import-learners"); s.add_argument("class_id"); s.add_argument("csv")
s = sub.add_parser("consent"); s.add_argument("id"); s.add_argument("status"); s.add_argument("--by", required=True)
s = sub.add_parser("export"); s.add_argument("id")
s = sub.add_parser("erase"); s.add_argument("id"); s.add_argument("--by", required=True); s.add_argument("--yes", action="store_true")
s = sub.add_parser("backup"); s.add_argument("path")
s = sub.add_parser("audit"); s.add_argument("--last", type=int, default=20)
a = ap.parse_args()
try:
    if a.cmd == "add-class": core.add_class(a.id, a.name, a.grade); print("ok")
    elif a.cmd == "add-teacher":
        pw = a.password or getpass.getpass("Password (10+ characters): "); core.create_teacher(a.name, pw, a.role, a.classes); print("ok")
    elif a.cmd == "add-learner": core.add_learner(a.id, a.cls, a.name, a.age_band); print("ok (consent is not yet recorded)")
    elif a.cmd == "import-learners":
        n = 0
        for r in csv.DictReader(open(a.csv, encoding="utf-8-sig")): core.add_learner(r["id"].strip(), a.class_id, r.get("name", ""), (r.get("age_band") or "9-12").strip()); n += 1
        print(f"imported {n} learners (consent is not yet recorded)")
    elif a.cmd == "consent": core.set_consent(a.id, a.status, a.by); print("ok")
    elif a.cmd == "export": print(json.dumps(core.export_learner(core.conn(), a.id), indent=1, default=str))
    elif a.cmd == "erase":
        if not a.yes and input(f"Permanently erase {a.id} and ALL their evidence? Type the ID to confirm: ") != a.id: sys.exit("cancelled")
        core.erase_learner(a.id, a.by); print("erased")
    elif a.cmd == "backup":
        dst = sqlite3.connect(a.path); core.conn().backup(dst); dst.close(); print("backup written to", a.path, "(contains child data: store it securely)")
    elif a.cmd == "audit":
        for r in core.conn().execute("SELECT * FROM audit ORDER BY id DESC LIMIT ?", (a.last,)): print(time.strftime("%Y-%m-%d %H:%M", time.localtime(r["at"])), r["actor"], r["action"], r["target"], r["detail"])
except (ValueError, KeyError) as e: sys.exit(f"error: {e}")
